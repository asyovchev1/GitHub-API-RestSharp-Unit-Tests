using RestSharp;
using RestSharp.Authenticators;
using System.Net;
using System.Text.Json;

namespace RestSharpGitHubUnitTestsProject
{
    public class UnitTests
    {
        RestClient client;

        [SetUp]
        public void Setup()
        {
            var options = new RestClientOptions("https://api.github.com")
            {
                MaxTimeout = 3000,
                Authenticator = new HttpBasicAuthenticator("asyovchev1", "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") //token expires on 23 March 2026
            };

            this.client = new RestClient(options);
        }

        [Test, Order(1)]
        public void Test_GitHubAPIRequest()
        {
            var request = new RestRequest("/repos/asyovchev1/IssuesTestRepo/issues", Method.Get);
            var response = client.Get(request);

            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(response.Content, Is.Not.Empty, "The response content should not be empty.");
        }

        [Test, Order(2)]
        public void Test_GetAllIssuesFromARepo()
        {
            var request = new RestRequest("/repos/asyovchev1/IssuesTestRepo/issues");
            var response = client.Execute(request);

            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(response.Content, Is.Not.Empty, "The response content should not be empty.");

            var issues = JsonSerializer.Deserialize<List<Issue>>(response.Content);

            Assert.That(issues.Count > 0);

            foreach (var issue in issues)
            {
                Assert.That(issue.id, Is.GreaterThan(0), "The issue ID should be greater than 0.");
                Assert.That(issue.number, Is.GreaterThan(0), "The issue number should be greater than 0.");
                Assert.That(issue.title, Is.Not.Empty, "The issue title should not be empty.");
                Assert.That(issue.body, Is.Not.Empty, "The issue body should not be empty.");
            }
        }

        [Test, Order(3)]
        public void Test_CreateNewGitHubIssue()
        {
            string title = "Another Test Issue";
            string body = "another test issue";
            var issue = CreateIssue(title, body);

            Assert.That(issue.id, Is.GreaterThan(0), "The issue ID should be greater than 0.");
            Assert.That(issue.number, Is.GreaterThan(0), "The issue number should be greater than 0.");
            Assert.That(issue.title, Is.Not.Empty, "The issue title should not be empty.");
            Assert.That(issue.body, Is.Not.Empty, "The issue body should not be empty.");
        }

        [Test, Order(4)]
        public void Test_EditIssue()
        {
            int number = GenerateNumber();

            var request = new RestRequest("/repos/asyovchev1/IssuesTestRepo/issues/6");
            request.AddJsonBody(new
            {
                body = "test body " + number
            });

            var response = client.Execute(request, Method.Patch);
            var issue = JsonSerializer.Deserialize<Issue>(response.Content);

            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            Assert.That(response.Content, Is.Not.Empty, "The response content should not be empty.");
            Assert.That(issue.id, Is.GreaterThan(0), "The issue ID should be greater than 0.");
            Assert.That(issue.number, Is.GreaterThan(0), "The issue number should be greater than 0.");
            Assert.That(issue.title, Is.EqualTo("TestIssue3"), "The issue title should not be changed.");
            Assert.That(issue.body, Is.Not.Empty, "The issue body should not be empty.");
        }

        [TearDown]
        public void Teardown()
        {
            this.client.Dispose();
        }

        private Issue CreateIssue(string title, string body)
        {
            var request = new RestRequest("/repos/asyovchev1/IssuesTestRepo/issues");
            request.AddBody(new { body, title });
            var response = client.Execute(request, Method.Post);

            Assert.That(response.StatusCode, Is.EqualTo(HttpStatusCode.Created));
            Assert.That(response.Content, Is.Not.Empty, "The response content should not be empty.");

            var issue = JsonSerializer.Deserialize<Issue>(response.Content);
            return issue;
        }

        private int GenerateNumber()
        {
            Random generator = new Random();
            int number = generator.Next(1, 1000000000);
            return number;
        }
    }
}
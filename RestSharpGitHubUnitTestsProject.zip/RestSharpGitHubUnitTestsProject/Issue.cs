﻿namespace RestSharpGitHubUnitTestsProject
{
    public class Issue
    {
        public long id { get; set; }

        public int number { get; set; }

        public string title { get; set; }

        public string body { get; set; }
    }
}
